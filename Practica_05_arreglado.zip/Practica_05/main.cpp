/** 
 * @file main.cpp
 * @author Casipro Gramo 
 * @author Yoyapro GRamo
 *
 * @date Fecha estelar 20160309
 */


//#include <cstdlib>
#include "Escuadron.h"
//#include<except>

void cargaDatos(Piloto vpilotos[]){
    vpilotos[0].setNombre("Dameron Poe")
               .setNacionalidad("Jakku")
               .setNumMisiones(100)
               .setFechaUltimaMision(123456)
               .setIncidenciasUltimaMision("Sin incidencias");

    vpilotos[1].setNombre("Anakin Skywalker")
               .setNacionalidad("Tatooine")
               .setNumMisiones(133)
               .setFechaUltimaMision(126756)
               .setIncidenciasUltimaMision("Derribados 3 cazas enemigos");

    vpilotos[2].setNombre("Han Solo")
               .setNacionalidad("Corellia")
               .setNumMisiones(247)
               .setFechaUltimaMision(126786)
               .setIncidenciasUltimaMision("Impacto en motor izquierdo");

    vpilotos[3].setNombre("Chewbacca")
               .setNacionalidad("Kashyyk")
               .setNumMisiones(115)
               .setFechaUltimaMision(136786)
               .setIncidenciasUltimaMision("Sin incidencias");


    vpilotos[4].setNombre("Leia Organa")
               .setNacionalidad("Alderaan")
               .setNumMisiones(3)
               .setFechaUltimaMision(126336)
               .setIncidenciasUltimaMision("Derribados 10 cazas enemigos");
}
void muestra(Piloto gamostrar[], int MAX){
    std::cout<<"Grupo de pilotos: "<<std::endl;
    for (int i = 0; i < MAX; ++i) {
        std::cout<<gamostrar[i].toCSV()<<std::endl;
    }
}



void cargaEscuadron(Piloto vpilotos[]){
    Escuadron PrimerEscuadron;
    PrimerEscuadron.setPiloto(vpilotos[1])
            .setPiloto(vpilotos[3]);
    std::cerr<<"Miembros del escuadron: "<<std::endl;
    for (int i = 1; i < PrimerEscuadron.getNumPilotos(); ++i) {
        std::cerr<<PrimerEscuadron.getPiloto(i)->getNombre()<<std::endl;
    }
    std::cout<<"EL PROMEDIO DE MISIONES DEL ESCUADRON ES: "<<PrimerEscuadron.promedioMisiones()<<std::endl;
}
int main2() {
    try {
        Piloto vpilotos[5];
        cargaDatos(vpilotos);
        cargaEscuadron(vpilotos);

        Escuadron GranEscuadron("Gran Escuadron",50,"Tattoine");
        //GranEscuadron.setPiloto(vpilotos[1]);
        muestra(vpilotos, 5);

    }catch(std::invalid_argument &error){
        std::cerr<<error.what()<<std::endl;
    }


    return 0;
}

int main3(){
    std::string frase=("Una pieza valiosa;520;Pieza de alto valor");
    Pieza unaPieza;
    unaPieza.fromCSV(frase);
    std::cout<<"Nombre: "<<unaPieza.getNombre()<<std::endl
    <<"Peso: "<<unaPieza.getPeso()<<std::endl
    <<"Descripcion: "<<unaPieza.getDescripcion()<<std::endl;

    std::string infoInforme=("124;4;20240516;No se han producido incidencias");
    Informe unInforme;
    unInforme.fromCSV(infoInforme);
    std::cout<<"ID Informe: "<<unInforme.getIdI()<<std::endl
    <<"ID Piloto: "<<unInforme.getIdPiloto()<<std::endl
    <<"Fecha estelar: "<<unInforme.getFechaEstelar()<<std::endl
    <<"Datos del informe: "<<unInforme.getDatosInforme()<<std::endl;

    try {
        std::string infoEscuadron("Grupo pilotos numero 48;60;Nabboo");
        Escuadron unEscuadron;
        unEscuadron.fromCSV(infoEscuadron);
        std::cout << "Nombre: " << unEscuadron.getNombre() << std::endl
                  << "Numero de pilotos: " << unEscuadron.getNumPilotos() << std::endl
                  << "Base: " << unEscuadron.getBase() << std::endl;
    }catch(std::invalid_argument &error){
        std::cerr<<error.what();
    }
}

int main5(){
    try {
        Piloto unpiloto("a");
        Escuadron unescuadron("nombre", 5, "base");
        unescuadron.setPiloto(unpiloto);
        std::cout << unescuadron.getPiloto(1);
    }catch(std::invalid_argument &error){
        std::cerr<<error.what();
    }
}

int mainpruebaspracticas(){
    Pieza unapieza("Motor",100,"Motor del SF");
    unapieza.setDescripcion("Nueva pieza");
    std::cout<<unapieza.getImprescindible()<<std::endl;

    StarFighter primeraNave("PrimeraMarca","PrimerModelo"),segundaNave;
    segundaNave=primeraNave;
    std::cout<<"La marca de la segunda nave es: "<<segundaNave.getMarca()<<std::endl;

}

int main() {
    try {
        StarFighter primeraNave("PrimeraMarca", "PrimerModelo");
        primeraNave.setPieza(Pieza("Regulador de flujo", 100, "Pieza 1"))
                .setPieza(Pieza("Canion laser medio alcance", 50, "Pieza 2"))
                .setPieza(Pieza("Canion laser medio alcance", 50, "Pieza 3"))
                .setPieza(Pieza("Reproductor de musica", 60, "MP100 3000W", 1));
        StarFighter segundaNave;
        segundaNave = primeraNave;
        std::cout << "La primera nave tiene " << primeraNave.getNumPiezasUtilizadas() << " piezas" << std::endl;
        primeraNave.muestraPiezas();

        std::cout << "La segunda nave tiene " << segundaNave.getNumPiezasUtilizadas() << " piezas" << std::endl;
        segundaNave.muestraPiezas();
    }catch(std::invalid_argument &error){
        std::cerr<<error.what()<<std::endl;
    }

    return 0;
}