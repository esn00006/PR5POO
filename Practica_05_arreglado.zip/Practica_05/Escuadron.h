//
// Created by aelit on 15/03/2024.
//

#ifndef PRUEBA_ESCUADRON_H
#define PRUEBA_ESCUADRON_H

#include "Piloto.h"

class Escuadron {
private:
std::string _nombre;
std::string _base;
const static int MAXPILOTOS=50;
Piloto *Pilotos[MAXPILOTOS];
int npilotosescuadron=1;

public:
    void inicializanull();

    Escuadron ();

    Escuadron(const std::string &nombre, int numPilotos, const std::string &base);

    virtual ~Escuadron();

    const std::string &getNombre() const;

    Escuadron &setNombre(const std::string &nombre);

    int getNumPilotos() const;

    Escuadron &setNumPilotos(int numPilotos);

    const std::string &getBase() const;

    Escuadron &setBase(const std::string &base);

    Escuadron &setPiloto(Piloto &nuevoPiloto); // Set y get se utilizan más bien para una sola unidad
    Piloto *getPiloto(int pospiloto);         // Cuando tenemos un conjunto de elementos, resulta mas conveniente cambiar el nombre a los métodos

    float promedioMisiones();

    void fromCSV(std::string CSV);

    //addpiloto(Piloto)
};




#endif //PRUEBA_ESCUADRON_H
