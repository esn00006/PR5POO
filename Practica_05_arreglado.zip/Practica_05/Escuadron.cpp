//
// Created by aelit on 15/03/2024.
//

#include "Escuadron.h"
#include<sstream>

void Escuadron::inicializanull() {
    for (int i = 0; i < MAXPILOTOS; ++i) {
        Pilotos[i]= nullptr;
    }
}

Escuadron::Escuadron() {
    inicializanull();
}

Escuadron::Escuadron(const std::string &nombre, int numPilotos, const std::string &base) : _nombre(nombre),
                                                                                           npilotosescuadron(numPilotos),
                                                                                           _base(base) {
    inicializanull();
    if(npilotosescuadron>50){
        throw std::invalid_argument("[Escuadron::Escuadron] El limite de pilotos en un escuadron es 50");
    }
    if(npilotosescuadron<1){
        throw std::invalid_argument("[Escuadron::Escuadron] El escuadron debe tener al menos a 1 piloto");
    }
}

Escuadron::~Escuadron() {
    for (int i = 0; i < npilotosescuadron; ++i) {
        if(Pilotos[i]!= nullptr){
            Pilotos[i]= nullptr;
        }
    }
}

const std::string &Escuadron::getNombre() const {
    return _nombre;
}

Escuadron &Escuadron::setNombre(const std::string &nombre) {
    _nombre = nombre;
    return *this;
}

int Escuadron::getNumPilotos() const {
    return npilotosescuadron;
}

Escuadron &Escuadron:: setNumPilotos(int numPilotos) {
    npilotosescuadron = numPilotos;
    return *this;
}

const std::string &Escuadron::getBase() const {
    return _base;
}

Escuadron &Escuadron::setBase(const std::string &base) {
    _base = base;
    return *this;
}

Escuadron &Escuadron::setPiloto(Piloto &nuevoPiloto){
    if(npilotosescuadron==MAXPILOTOS){
        throw std::invalid_argument("[Escuadron::setPiloto] Se ha llegado al limite del escuadron, no se aniadira al piloto");
    }
    Pilotos[npilotosescuadron]=&nuevoPiloto;
    ++npilotosescuadron;
    return *this;
}

Piloto *Escuadron::getPiloto(int pospiloto) {
    if(Pilotos[pospiloto]== nullptr) {
        throw std::invalid_argument("[Escuadron::getPiloto] No hay ningun piloto en la posicion indicada");
    }
    return Pilotos[pospiloto];

}

float Escuadron::promedioMisiones(){
    float promedio=0;
    for (int i = 1; i < npilotosescuadron; ++i) {
        promedio+=Pilotos[i]->getNumMisiones();
    }
    return promedio/(npilotosescuadron-1);
}

void Escuadron::fromCSV(std::string CSV) {
    std::stringstream ss;
    ss<<CSV;
    getline(ss,_nombre,';');
    ss>>npilotosescuadron;
    ss.ignore(1);
    getline(ss,_base,';');

}