//
// Created by aelit on 15/03/2024.
//

#ifndef PRUEBA_PIEZA_H
#define PRUEBA_PIEZA_H
#include<iostream>


class Pieza {
private:
    std::string _nombre;
    float _peso=0;
    std::string _descripcion;
    bool _imprescindible=false;

public:
    Pieza();
    Pieza(const std::string &nombre, float peso, const std::string &descripcion,bool imprescindible=false);
    virtual ~Pieza();

    const std::string &getNombre() const;

    Pieza setNombre(const std::string &nombre);

    float getPeso() const;

    Pieza setPeso(float peso);

    const std::string &getDescripcion() const;

    Pieza &setDescripcion(const std::string &descripcion);

    void fromCSV(std::string CSV);
    std::string toCSV() const;

    bool getImprescindible() const;

    Pieza &setImprescindible(bool imprescindible);
};



#endif //PRUEBA_PIEZA_H
