/** 
 * @file Piloto.cpp
 * @author Yoyapro Gramo
 * 
 * @date Fecha estelar 20160309
 */

#include <stdexcept>
#include <sstream>
#include "Piloto.h"

using std::string;

int Piloto::_numPilotos = 0; // Inicializacion de la variable de clase

Piloto::Piloto ( ): Piloto ( "" )
{ }

Piloto::Piloto ( string nombre ): _nombre (nombre)
{
   _numPilotos++;
   _idP = _numPilotos;
}

Piloto::Piloto ( const Piloto& orig ): _nombre(orig._nombre),
                                       _nacionalidad(orig._nacionalidad),
                                       _numMisiones(orig._numMisiones),
                                       _fechaUltimaMision(orig._fechaUltimaMision),
                                       _incidenciasUltimaMision(orig._incidenciasUltimaMision)
{
   _numPilotos++;
   _idP = _numPilotos;
}

Piloto::~Piloto ( )
{
    if(_navePiloto!= nullptr){
        _navePiloto= nullptr;
    }
    if(_droidePiloto!= nullptr){
        _droidePiloto= nullptr;
    }
}

/**
 * Aquí hay que añadir la comprobación del parámetro y lanzar la excepción
 * correspondiente. El número de misiones no puede ser <= 0
 */
Piloto &Piloto::setNumMisiones ( int numMisiones )
{
    if(numMisiones<=0){
        throw std::invalid_argument("El numero de misiones no puede ser <=0");
    }
   this->_numMisiones = numMisiones;
   return *this;
}

int Piloto::getNumMisiones ( ) const
{
   return _numMisiones;
}

Piloto &Piloto::setNacionalidad ( string nacionalidad )
{
   this->_nacionalidad = nacionalidad;
   return *this;
}

string Piloto::getNacionalidad ( ) const
{
   return _nacionalidad;
}

Piloto &Piloto::setNombre ( string nombre )
{
   this->_nombre = nombre;
   return *this;
}

string Piloto::getNombre ( ) const
{
   return _nombre;
}

int Piloto::getIdP ( ) const
{
   return _idP;
}

/**
 * Si el número de misiones del piloto es 0, no puede tener incidencias;
 * haz esta comprobación y lanza la excepción correspondiente
 */
Piloto &Piloto::setIncidenciasUltimaMision ( string incidenciasUltimaMision )
{
    if(this->_numMisiones==0){
        throw std::invalid_argument("El piloto no ha realizado misiones, por lo que no puede tener incidencias");
    }
   this->_incidenciasUltimaMision = incidenciasUltimaMision;
   return *this;

}

string Piloto::getIncidenciasUltimaMision ( ) const
{
   return _incidenciasUltimaMision;
}

/**
 * Si el número de misiones del piloto es 0, no puede tener fecha de
 * última misión; haz esta comprobación y lanza la excepción
 * correspondiente
 */
Piloto &Piloto::setFechaUltimaMision ( long fechaUltimaMision )
{
    if(this->_numMisiones==0){
        throw std::invalid_argument("El piloto no ha realizado misiones, por lo que no puede tener fecha de ultima mision");
    }
   this->_fechaUltimaMision = fechaUltimaMision;
   return *this;
}

/**
 * Si el número de misiones del piloto es 0, no puede tener fecha de
 * última misión; haz esta comprobación y lanza la excepción
 * correspondiente
 */
long Piloto::getFechaUltimaMision ( ) const
{
    if(this->_numMisiones==0){
        throw std::invalid_argument("El piloto no ha realizado misiones, por lo que no puede tener fecha de ultima mision");
    }
   return _fechaUltimaMision;
}

string Piloto::toCSV () const
{
   std::stringstream aux;

   aux << _nombre << " ; "
       << _nacionalidad << " ; "
       << _numMisiones << " ; "
       << _fechaUltimaMision << " ; "
       << _incidenciasUltimaMision<<std::endl;

   return ( aux.str () );
}

Piloto& Piloto::operator = ( const Piloto& otro )
{
   if ( this != &otro )
   {
      _nombre = otro._nombre;
      _nacionalidad = otro._nacionalidad;
      _numMisiones = otro._numMisiones;
      _fechaUltimaMision = otro._fechaUltimaMision;
      _incidenciasUltimaMision = otro._incidenciasUltimaMision;
   }
   
   return ( *this );
}

StarFighter Piloto::getNavePiloto() const {
    return *_navePiloto;
}

Piloto &Piloto::setNavePiloto(StarFighter &navePiloto) {
    _navePiloto = &navePiloto;
    return *this;
}

Droide Piloto::getDroidePiloto() const {
    return *_droidePiloto;
}

Piloto &Piloto::setDroidePiloto(Droide &droidePiloto) {
    if(droidePiloto.getModelo()[0]!='R'){
        throw std::invalid_argument("[Piloto::setDroidePiloto] Para asignar un droide al piloto, debe ser del modelo R");
    }
    if(droidePiloto.getAveriado()){
        throw std::invalid_argument("[Piloto::setDroidePiloto] No se puede asignar un droide averiado a un piloto");
    }
    _droidePiloto = &droidePiloto;
    return *this;
}

Informe Piloto::GeneraInforme(){
    if(_droidePiloto== nullptr){
        throw std::invalid_argument("[Piloto::GeneraInforme] El piloto no tiene droides");
    }
    if(_navePiloto== nullptr){
        throw std::invalid_argument("[Piloto::GeneraInforme] El piloto no tiene naves");
    }
    Informe NuevoInforme;
    NuevoInforme.setFechaEstelar(_fechaUltimaMision);
    NuevoInforme.setIdPiloto(_idP);
    NuevoInforme.setDatosInforme("Nave: "+_navePiloto->toCSV()
    +" Droide acompaniante: "+_droidePiloto->toCSV());
    return NuevoInforme;
}

void Piloto::fromCSV ( string& datos )
{
    std::stringstream aux;

    aux << datos;

    getline ( aux, this->_nombre, ';' );
    getline ( aux, this->_nacionalidad, ';' );
    aux >> this->_numMisiones;
    aux.ignore (1);
    aux >> this->_fechaUltimaMision;
    aux.ignore (1);
    getline ( aux, this->_incidenciasUltimaMision );
}