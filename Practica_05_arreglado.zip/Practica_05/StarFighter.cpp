/** 
 * @file StarFighter.cpp
 * @author Casipro Gramo
 * 
 * @date Fecha estelar 20160309
 */

#include <stdexcept>
#include <sstream>

#include "StarFighter.h"

using std::string;

int StarFighter::_numStarFighters = 0;
void StarFighter::inicializaPiezasSF(){
    for (int i = 0; i < MAXPIEZAS; ++i) {
        Piezas[i]= nullptr;
    }
}

StarFighter::StarFighter ( ): StarFighter ( "", "" )
{
    inicializaPiezasSF();
}

StarFighter::StarFighter ( string marca, string modelo ): _marca (marca),
                                                          _modelo(modelo)
{
    inicializaPiezasSF();
   _numStarFighters++;
   _idSF = 1000+_numStarFighters;
}

StarFighter::StarFighter ( const StarFighter& orig ): _marca(orig._marca),
                                                      _modelo(orig._modelo),
                                                      _numPlazas(orig._numPlazas)
{
    inicializaPiezasSF();
   _numStarFighters++;
   _idSF = _numStarFighters;

}

StarFighter::~StarFighter ( )
{
    for (int i = 0; i < MAXPIEZAS; ++i) {
        if(Piezas[i]!= nullptr){
            delete Piezas[i];
            Piezas[i]= nullptr;
        }
    }
}

/**
 * Aquí hay que añadir la comprobación del parámetro y lanzar la excepción
 * correspondiente. El número de plazas no puede ser <= 0
 */
StarFighter &StarFighter::setNumPlazas ( int numPlazas )
{
    if(numPlazas<=0){
        throw std::invalid_argument("[Starfighter::setNumPlazas] El numero de plazas no puede ser <=0");
    }
   this->_numPlazas = numPlazas;
   return *this;
}

int StarFighter::getNumPlazas ( ) const
{
   return _numPlazas;
}

StarFighter &StarFighter::setModelo ( string modelo )
{
   this->_modelo = modelo;
   return *this;
}

string StarFighter::getModelo ( ) const
{
   return _modelo;
}

StarFighter &StarFighter::setMarca ( string marca )
{
   this->_marca = marca;
   return *this;
}

string StarFighter::getMarca ( ) const
{
   return _marca;
}

int StarFighter::getIdSF ( ) const
{
   return _idSF;
}

string StarFighter::toCSV () const
{
   std::stringstream aux;

   aux <<"marca: "<< _marca << " ; "
       <<"modelo: "<< _modelo << " ; "
       <<"num plazas: "<< _numPlazas<<" ; "
       <<"parsecs: "<<_parsecs<<" ; "
       <<"numero de piezas utilizadas: "<<_numPiezasUtilizadas<<std::endl;

   return ( aux.str () );
}


double StarFighter::getParsecs() const {
    return _parsecs;
}

void StarFighter::incrementarParsecs(double parsecs) {
    if(parsecs>=0) _parsecs+=parsecs;
    else throw std::invalid_argument ("[Starfighter::incrementarParsecs] El numero de parsecs a incrementar debe ser un valor positivo");
}

Pieza *const *StarFighter::getPiezas() const {
    return Piezas;
}

int StarFighter::getNumPiezasUtilizadas() const {
    return _numPiezasUtilizadas;
}


StarFighter &StarFighter::setPieza(Pieza nuevapieza){
    if(_numPiezasUtilizadas==50){
        throw std::invalid_argument("[StarFighter::setPieza] Se ha llegado al limite de la nave, no se aniadira la pieza");
    }
    Piezas[_numPiezasUtilizadas]=new Pieza(nuevapieza);
    ++_numPiezasUtilizadas;
    return *this;
}
StarFighter &StarFighter::deletePieza(int numpieza) {
    if(_numPiezasUtilizadas==1){
        throw std::invalid_argument("[StarFighter::deletePieza] La nave no puede tener menos de 1 pieza");
    }
    numpieza-=1; // Para que, si se quiere eliminar la segunda pieza, se acceda a la pieza que ocupa
                 // el segundo lugar, no a la pieza que ocupa la posicion 2 del vector
    delete Piezas[numpieza];
    Piezas[numpieza]= nullptr;
    --_numPiezasUtilizadas;

    if(_numPiezasUtilizadas>numpieza){
        for (int i = numpieza; i < _numPiezasUtilizadas; ++i) {
            Piezas[i]=Piezas[i+1];
        }
        Piezas[_numPiezasUtilizadas]= nullptr;
    }
    return *this;
}

float StarFighter::calculaPeso() {
    float pesoTotal=0;
    for (int i = 0; i < _numPiezasUtilizadas; ++i) {
        pesoTotal+=Piezas[i]->getPeso();
    }
    return pesoTotal;
}
void StarFighter::fromCSV (string& datos)
{
    std::stringstream aux;

    aux << datos;

    getline ( aux, _marca, ';' );
    getline ( aux, _modelo, ';' );
    aux >> _numPlazas;
}

StarFighter &StarFighter:: operator=(const StarFighter &orig){
    ++_numStarFighters;
    _marca=orig._marca;
    _modelo=orig._modelo;
    _numPlazas=orig._numPlazas;
    for (int i = 0; i < orig._numPiezasUtilizadas; ++i) {
        if(orig.Piezas[i]->getImprescindible()==1){
            Piezas[_numPiezasUtilizadas]=new Pieza(*orig.Piezas[i]);
            ++_numPiezasUtilizadas;
        }
    }
    return(*this);
}

void StarFighter::muestraPiezas() {
    std::cout<<"Mostrando piezas de la nave con ID:"<<_idSF<<std::endl;
    for (int i = 0; i < _numPiezasUtilizadas; ++i) {
        std::cout<<Piezas[i]->toCSV();
    }
}