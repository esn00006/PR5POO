/** 
 * @file StarFighter.h
 * @author Casipro Gramo
 *
 * @date Fecha estelar 20160309
 */

#ifndef STARFIGHTER_H
#define STARFIGHTER_H

#include <string>
#include "Pieza.h"

/**
 * @brief
 */
class StarFighter
{
   private:
      static int _numStarFighters; ///< Número de objetos de esta clase instanciados
      int _idSF=0; ///< Identificador único de la nave
      std::string _marca; ///< Marca de la nave (parece que las VW contaminan más)
      std::string _modelo; ///< Modelo de la nava
      int _numPlazas; ///< Número de plazas de la nave
      double _parsecs=0; /// Numero de parsecs (revisión cada 5000)
      const static int MAXPIEZAS=50;
      Pieza *Piezas[MAXPIEZAS];
      int _numPiezasUtilizadas=0;

   public:
    StarFighter &operator= ( const StarFighter &orig );
    void inicializaPiezasSF();
    StarFighter ();
      StarFighter ( std::string marca, std::string modelo );
      StarFighter ( const StarFighter& orig );
      virtual ~StarFighter ( );
      StarFighter &setNumPlazas ( int numPlazas );
      int getNumPlazas ( ) const;
      StarFighter &setModelo ( std::string modelo );
      std::string getModelo ( ) const;
      StarFighter &setMarca ( std::string marca );
      std::string getMarca ( ) const;
      int getIdSF ( ) const;
      std::string toCSV () const;
      double getParsecs() const;
      void incrementarParsecs(double parsecs);

    Pieza *const *getPiezas() const;

    int getNumPiezasUtilizadas() const;

    StarFighter &setPieza(Pieza nuevapieza);
    StarFighter &deletePieza(int numpieza);

    float calculaPeso();

    void fromCSV ( std::string& datos );
    void muestraPiezas();


};

#endif /* STARFIGHTER_H */

