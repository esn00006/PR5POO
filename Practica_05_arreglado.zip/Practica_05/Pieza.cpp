//
// Created by aelit on 15/03/2024.
//

#include "Pieza.h"
#include<sstream>

Pieza::Pieza(){}

Pieza::Pieza(const std::string &nombre, float peso, const std::string &descripcion, bool imprescindible) : _nombre(nombre), _peso(peso),
                                                                                      _descripcion(descripcion), _imprescindible(imprescindible) {
    if(peso<0){
        std::invalid_argument("[Pieza::Pieza] El peso de una pieza no puede ser negativo");
    }
}

Pieza::~Pieza() {

}

const std::string &Pieza::getNombre() const {
    return _nombre;
}

Pieza Pieza::setNombre(const std::string &nombre) {
    _nombre = nombre;
    return *this;
}

float Pieza::getPeso() const {
    return _peso;
}

Pieza Pieza::setPeso(float peso) {
    if(peso<0)
    {
        std::invalid_argument("[Pieza::setPeso] El peso de una pieza no puede ser negativo");
    }
    Pieza::_peso = peso;
    return *this;
}

const std::string &Pieza::getDescripcion() const {
    return _descripcion;
}

Pieza &Pieza::setDescripcion(const std::string &descripcion) {
    _descripcion = descripcion;
    return *this;
}

//ToDo Explicacion fromCSV
void Pieza::fromCSV(std::string CSV){
    std::stringstream ss;
    // Inicializamos el contenido de ss
    ss<<CSV;

    // Leemos los parametros necesarios (importante poner getline para no perder informacion)
    getline(ss,_nombre,';'); // El caracter ';' se lee y se elimina de la cadena

    // El operador >> transforma cada cadena en el tipo necesario;
    ss>>_peso;
    ss.ignore(1); // Para que ignore el ; que le sigue al peso
    getline(ss,_descripcion);
}

bool Pieza::getImprescindible() const {
    return _imprescindible;
}

Pieza &Pieza::setImprescindible(bool imprescindible) {
    _imprescindible = imprescindible;
    return *this;
}

std::string Pieza::toCSV() const {
    std::string imp;
    if(_imprescindible){
        imp="Si";
    }else{
        imp="No";
    }
    std::stringstream aux;
    aux<<"Nombre pieza: "<<_nombre<<" ; "
       <<"Peso pieza: "<<_peso<<" ; "
       <<"Descripcion pieza: "<<_descripcion<<" ; "
       <<"Es imprescindible: "<<imp<<std::endl;

    return aux.str();
}