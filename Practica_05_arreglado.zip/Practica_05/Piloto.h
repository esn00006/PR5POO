/** 
 * @file Piloto.h
 * @author Yoyapro Gramo
 *
 * @date Fecha estelar 20160309
 */

#ifndef PILOTO_H
#define PILOTO_H

#include "StarFighter.h"
#include "Droide.h"
#include"Informe.h"

/**
 * @brief
 */
class Piloto
{
   private:
      static int _numPilotos; // Las variables de clase no se pueden inicializar aqui, TIENE QUE SER EN EL CPP
                              ///< Número de objetos Piloto que han sido instanciados
      int _idP = 0;                       ///< Identificador único del Piloto
      std::string _nombre;                ///< Nombre del Piloto
      std::string _nacionalidad;          ///< Nacionalidad del Piloto
      int _numMisiones = 0;        ///< Número de misiones en que ha participado
      long _fechaUltimaMision = 0;        ///< Fecha estelar de su última misión
      std::string _incidenciasUltimaMision; ///< Incidencias reportadas por el piloto en su última misión.
      StarFighter *_navePiloto= nullptr;             ///< Nave del piloto
      Droide *_droidePiloto= nullptr;               ///< Droide que ayuda al piloto


   public:
      Piloto ( );
      Piloto ( std::string nombre );
      Piloto ( const Piloto& orig );
      virtual ~Piloto ( );
      Piloto &setNumMisiones ( int numMisiones );
      int getNumMisiones ( ) const;
      Piloto &setNacionalidad ( std::string nacionalidad );
      std::string getNacionalidad ( ) const;
      Piloto &setNombre ( std::string nombre );
      std::string getNombre ( ) const;
      int getIdP ( ) const;
      Piloto &setIncidenciasUltimaMision ( std::string incidenciasUltimaMision );
      std::string getIncidenciasUltimaMision ( ) const;
      Piloto &setFechaUltimaMision ( long fechaUltimaMision );
      long getFechaUltimaMision ( ) const;
      std::string toCSV () const;
      Piloto& operator= ( const Piloto& otro );

      StarFighter getNavePiloto() const;
      Piloto &setNavePiloto(StarFighter &navePiloto);

      Droide getDroidePiloto() const;
      Piloto &setDroidePiloto(Droide &droidePiloto);

      Informe GeneraInforme();

    void fromCSV ( std::string& datos );


};

#endif /* PILOTO_H */

